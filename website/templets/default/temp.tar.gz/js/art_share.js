// JavaScript Document IT.com.cn  文章页 WEB2.0分享模块 GAN.

document.writeln("    <!--web2.0分享模块  开始-->");

document.writeln("	<div class=\"px10\"></div>");

document.writeln("    <div class=\"web2\">");

document.writeln("    	<div class=\"web_zi\">快速分享到</div>");

document.writeln("        <div class=\"web_defo\">");

document.writeln("            <a class=\"shareto_button_tsina\" title=\"新浪微博\"></a>");

document.writeln("            <a class=\"shareto_button_qzone\" title=\"Qzone\"></a>");

document.writeln("            <a class=\"shareto_button_hi\" title=\"百度空间\"></a>");

document.writeln("            <a class=\"shareto_button_renren\" title=\"人人网\"></a>");

document.writeln("            <a class=\"shareto_button_douban\" title=\"豆瓣\"></a>");

document.writeln("            <a class=\"shareto_button_yahoo\" title=\"雅虎收藏\"></a>");

document.writeln("        </div>");

document.writeln("        <div class=\"web_an\">");

document.writeln("       	  <ul id=\"g_nav\">");

document.writeln("        		<li>");

document.writeln("                		<div class=\"web_over\">");

document.writeln("                            <div class=\"web_more\">");

document.writeln("                                <b><a class=\"shareto_button_gmail\" title=\"Gmail\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_qq\" title=\"QQ书签\"></a></b>");

document.writeln("<b><a href=\"http://www.dig24.cn/share/crawler.dhtml\" target=\"_blank\" class=\"button_dike\">递客</a></b>");

document.writeln("                                <b><a class=\"shareto_button_baidu\" title=\"百度收藏\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_51\" title=\"51社区\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_google\" title=\"谷歌收藏\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_taojianghu\" title=\"淘江湖\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_vivi\" title=\"新浪收藏\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_itieba\" title=\"i 贴吧\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_yahoo\" title=\"雅虎收藏\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_bai\" title=\"白社会\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_live\" title=\"Hotmail\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_douban9\" title=\"豆瓣9点\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_kaixin001\" title=\"开心网\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_xianguo\" title=\"鲜果\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_buzz\" title=\"Google Buzz\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_live\" title=\"Live收藏\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_leshou\" title=\"乐收网\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_qzone\" title=\"Qzone\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_youdao\" title=\"有道书签\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_t163\" title=\"网易微博\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_csdn\" title=\"CSDN网摘\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_tsohu\" title=\"搜狐微博\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_hexun\" title=\"和讯收藏\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_t139\" title=\"139说客\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_yahoo\" title=\"Yahoo! mail\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_myspace\" title=\"Myspace\"></a></b>");

document.writeln("                                <b><a class=\"shareto_button_digg\" title=\"Digg\"></a></b>");

document.writeln("                                <div class=\"clear\"></div>");

document.writeln("                            </div>");

document.writeln("                            <div class=\"web_on\">&nbsp;</div>");

document.writeln("                        </div>");

document.writeln("                </li>");

document.writeln("            </ul>");

document.writeln("        </div>");

document.writeln("    </div>");

document.writeln("<script type=\"text/javascript\" src=\"/templets/default/js/art_web20.js\" charset=utf-8></script> <!--web2.0模块JS-->");

document.writeln("<style type=\"text/css\">@import url(/templets/default/style/share.css);</style><!--分享模块CSS文件-->");

document.writeln("    <div class=\"px10\"></div>");

document.writeln("	<div class=\"px10\"></div>");

document.writeln("    <!--web2.0分享模块  结束-->");



